Project title:
Sole Table

Author:
A-team 23


Team member, email, xteam:
Alex Pletta, (apletta@wisc.edu), xteam-24
Grace Joyce, (gjoyce@wisc.edu), xteam-24
Joziah Mays, (jmays2@wisc.edu), xteam-24
Lu Duan,     (lduan23@wisc.edu), xteam-24
Liang Shang, (lshang6@wisc.edu), xteam-104